<?php
echo(rand(10,100));
?>