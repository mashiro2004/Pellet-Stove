#!/bin/bash
crontab -u www-data -l > /var/www/html/php/sett/skfile
sed -i -e :a -e '/^\n*$/{$d;N;ba' -e '}' /var/www/html/php/sett/skfile
crontab -u www-data /var/www/html/php/sett/skfile