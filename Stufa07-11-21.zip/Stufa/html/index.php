<?php
header("location: /php/welcome.php")
?>