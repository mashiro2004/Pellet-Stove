#!/bin/sh
sleep 1
irsend SEND_ONCE Extraflame KEY_RIGHT
sleep 1
irsend SEND_ONCE Extraflame KEY_LEFT

 
