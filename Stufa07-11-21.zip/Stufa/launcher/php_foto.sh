#!/bin/sh
/bin/sh video.sh & #this doesn't blocks!
/bin/sh up.sh

 
