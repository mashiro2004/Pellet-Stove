#!/bin/sh
fswebcam -v --set Exposure=1 -r 640x480 --jpeg 100 /var/www/html/img/stato.jpg