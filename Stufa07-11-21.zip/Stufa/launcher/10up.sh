#!/bin/bash
irsend SEND_ONCE Extraflame KEY_LEFT
sleep 1
irsend SEND_ONCE Extraflame KEY_LEFT
sleep 1
irsend SEND_ONCE Extraflame KEY_LEFT
sleep 1
irsend SEND_ONCE Extraflame KEY_LEFT
sleep 1
irsend SEND_ONCE Extraflame KEY_LEFT
sleep 1
irsend SEND_ONCE Extraflame KEY_LEFT
sleep 1
irsend SEND_ONCE Extraflame KEY_LEFT
sleep 1
irsend SEND_ONCE Extraflame KEY_LEFT
sleep 1
irsend SEND_ONCE Extraflame KEY_LEFT
sleep 1
irsend SEND_ONCE Extraflame KEY_LEFT
sleep 1