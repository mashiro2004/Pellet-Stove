#!/bin/bash
irsend SEND_ONCE Extraflame KEY_DOWN